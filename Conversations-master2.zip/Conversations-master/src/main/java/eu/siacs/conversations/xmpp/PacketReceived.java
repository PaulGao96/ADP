package eu.siacs.conversations.xmpp;

public abstract interface PacketReceived {

}
